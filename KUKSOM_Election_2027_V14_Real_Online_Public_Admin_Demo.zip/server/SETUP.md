
# KUKSOM Election 2027 — V8 Backend

## Requirements
- Node.js 18+ (20+ recommended)
- npm

## Start
```bash
cd server
npm install
# Linux/macOS:
export JWT_SECRET="replace-with-a-long-random-secret"
export ADMIN_PASSWORD="replace-with-a-strong-password"
npm start
```

Windows PowerShell:
```powershell
$env:JWT_SECRET="replace-with-a-long-random-secret"
$env:ADMIN_PASSWORD="replace-with-a-strong-password"
npm start
```

API:
`http://localhost:3000/api/health`

The first run creates `kuksom.db`, seeds the 11 Kumbotso wards and election categories, and creates an admin account from `ADMIN_PASSWORD`.

## Security before public deployment
- Change `JWT_SECRET` and admin password.
- Use HTTPS.
- Put the API behind a reverse proxy.
- Restrict CORS to the actual frontend domain.
- Keep uploads outside public execution paths where appropriate.
- Add rate limiting, backups, monitoring and server-side validation.
- Verify polling-unit data against the latest authoritative INEC directory.
- Do not describe KUKSOM-collected data as official INEC results.
