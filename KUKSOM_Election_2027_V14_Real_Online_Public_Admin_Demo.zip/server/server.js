
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET_BEFORE_PRODUCTION";
const ROOT = __dirname;
const DB_FILE = path.join(ROOT, "kuksom.db");
const UPLOADS = path.join(ROOT, "uploads");
fs.mkdirSync(UPLOADS, { recursive: true });

app.use(cors({ origin: process.env.CORS_ORIGIN || true }));
app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({extended:true}));
app.use("/uploads", express.static(UPLOADS));
app.use(express.static(path.join(ROOT, "public")));

const db = new Database(DB_FILE);
db.pragma("foreign_keys = ON");
db.exec(fs.readFileSync(path.join(ROOT,"schema.sql"),"utf8"));

const wards = ["Challawa","Chiranchi","Danbare","Danmaliki","Guringawa","Kumbotso","Kureken Sani","Mariri","Na'ibawa","Panshekara","Unguwar Rimi"];
const wardInsert = db.prepare("INSERT OR IGNORE INTO wards(name) VALUES(?)");
for (const w of wards) wardInsert.run(w);

const electionTypes = ["Presidential","Governorship","Senatorial","House of Representatives","State House of Assembly"];
for (const t of electionTypes) db.prepare("INSERT OR IGNORE INTO elections(type) VALUES(?)").run(t);

if (!db.prepare("SELECT 1 FROM users LIMIT 1").get()) {
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD || "KUKSOM2027", 12);
  db.prepare("INSERT INTO users(name,username,password_hash,role) VALUES(?,?,?,?)")
    .run("System Administrator","admin",hash,"Admin");
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_,__,cb)=>cb(null,UPLOADS),
    filename: (_,file,cb)=>cb(null,Date.now()+"-"+file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_"))
  }),
  limits:{fileSize:10*1024*1024}
});

function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Authentication required"});
  try { req.user=jwt.verify(h.slice(7),JWT_SECRET); next(); }
  catch(e){ return res.status(401).json({error:"Invalid or expired token"}); }
}
function role(...roles){
  return (req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({error:"Insufficient permission"});
}
function audit(userId,action,entity,entityId,details=""){
  db.prepare("INSERT INTO audit_logs(user_id,action,entity,entity_id,details) VALUES(?,?,?,?,?)")
    .run(userId,action,entity,entityId,details);
}

app.get("/api/health",(req,res)=>res.json({ok:true,service:"KUKSOM Election 2027 API",time:new Date().toISOString()}));

app.post("/api/auth/login",(req,res)=>{
  const {username,password}=req.body||{};
  const u=db.prepare("SELECT * FROM users WHERE username=? AND status='Active'").get(username);
  if(!u || !bcrypt.compareSync(password||"",u.password_hash)) return res.status(401).json({error:"Invalid credentials"});
  const token=jwt.sign({id:u.id,username:u.username,name:u.name,role:u.role},JWT_SECRET,{expiresIn:"8h"});
  audit(u.id,"LOGIN","user",u.id);
  res.json({token,user:{id:u.id,name:u.name,username:u.username,role:u.role}});
});

app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.get("/api/wards",(req,res)=>{
  res.json(db.prepare("SELECT * FROM wards ORDER BY name").all());
});

app.get("/api/polling-units",(req,res)=>{
  const wardId=req.query.ward_id;
  const rows=wardId
    ? db.prepare("SELECT p.*,w.name ward_name FROM polling_units p JOIN wards w ON w.id=p.ward_id WHERE p.ward_id=? ORDER BY p.code").all(wardId)
    : db.prepare("SELECT p.*,w.name ward_name FROM polling_units p JOIN wards w ON w.id=p.ward_id ORDER BY w.name,p.code").all();
  res.json(rows);
});

app.post("/api/polling-units",auth,role("Admin","Verifier"),(req,res)=>{
  const {ward_id,code,name,status="Active"}=req.body||{};
  if(!ward_id||!code||!name) return res.status(400).json({error:"ward_id, code and name are required"});
  try{
    const r=db.prepare("INSERT INTO polling_units(ward_id,code,name,status) VALUES(?,?,?,?)").run(ward_id,code,name,status);
    audit(req.user.id,"CREATE","polling_unit",r.lastInsertRowid,JSON.stringify(req.body));
    res.status(201).json({id:r.lastInsertRowid});
  }catch(e){res.status(400).json({error:"Polling Unit code already exists in this ward or data is invalid"});}
});

app.get("/api/elections",(req,res)=>res.json(db.prepare("SELECT * FROM elections ORDER BY id").all()));

app.get("/api/results",(req,res)=>{
  const rows=db.prepare(`
    SELECT r.*,e.type election_type,p.code pu_code,p.name pu_name,w.name ward_name,u.name submitted_by_name, (SELECT COUNT(*) FROM result_files rf WHERE rf.result_id=r.id) file_count
    FROM results r JOIN elections e ON e.id=r.election_id
    JOIN polling_units p ON p.id=r.polling_unit_id JOIN wards w ON w.id=p.ward_id
    JOIN users u ON u.id=r.submitted_by ORDER BY r.id DESC`).all();
  const votes=db.prepare("SELECT result_id,party,votes FROM result_votes").all();
  const by={}; for(const v of votes){(by[v.result_id]??=[]).push({party:v.party,votes:v.votes});}
  res.json(rows.map(x=>({...x,votes:by[x.id]||[]})));
});

app.post("/api/results",auth,role("Admin","Data Collector"),(req,res)=>{
  const {election_id,polling_unit_id,votes={},notes=""}=req.body||{};
  const parties=["APC","PDP","NDC","ADC","NNPP"];
  if(!election_id||!polling_unit_id) return res.status(400).json({error:"election_id and polling_unit_id are required"});
  const clean={}; for(const p of parties){ const n=Number(votes[p]??0); if(!Number.isInteger(n)||n<0) return res.status(400).json({error:`Invalid votes for ${p}`}); clean[p]=n; }
  try{
    const tx=db.transaction(()=>{
      const r=db.prepare("INSERT INTO results(election_id,polling_unit_id,submitted_by,notes) VALUES(?,?,?,?)").run(election_id,polling_unit_id,req.user.id,notes);
      const ins=db.prepare("INSERT INTO result_votes(result_id,party,votes) VALUES(?,?,?)");
      for(const p of parties) ins.run(r.lastInsertRowid,p,clean[p]);
      audit(req.user.id,"SUBMIT","result",r.lastInsertRowid,JSON.stringify(clean));
      return r.lastInsertRowid;
    });
    res.status(201).json({id:tx,status:"Pending"});
  }catch(e){res.status(400).json({error:"A result already exists for this election and polling unit, or the data is invalid"});}
});

app.post("/api/results/:id/verify",auth,role("Admin","Verifier"),(req,res)=>{
  const status=req.body?.status;
  if(!["Verified","Rejected"].includes(status)) return res.status(400).json({error:"Status must be Verified or Rejected"});
  const r=db.prepare("UPDATE results SET status=?,verified_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(status,req.user.id,req.params.id);
  if(!r.changes) return res.status(404).json({error:"Result not found"});
  audit(req.user.id,status==="Verified"?"VERIFY":"REJECT","result",req.params.id,req.body?.notes||"");
  res.json({ok:true,status});
});

app.post("/api/results/:id/files",auth,role("Admin","Data Collector","Verifier"),upload.single("file"),(req,res)=>{
  if(!req.file) return res.status(400).json({error:"File required"});
  const allowed=["image/jpeg","image/png","application/pdf"];
  if(!allowed.includes(req.file.mimetype)){ try{fs.unlinkSync(req.file.path)}catch(_){} return res.status(400).json({error:"Only JPG, PNG or PDF files are allowed"}); }
  const result=db.prepare("SELECT id FROM results WHERE id=?").get(req.params.id);
  if(!result) return res.status(404).json({error:"Result not found"});
  const r=db.prepare("INSERT INTO result_files(result_id,original_name,stored_name,mime_type,file_size,uploaded_by) VALUES(?,?,?,?,?,?)")
    .run(req.params.id,req.file.originalname,req.file.filename,req.file.mimetype,req.file.size,req.user.id);
  audit(req.user.id,"UPLOAD","result_file",r.lastInsertRowid,req.file.originalname);
  res.status(201).json({id:r.lastInsertRowid,file:"/uploads/"+req.file.filename});
});


/* Public endpoint: verified data only. Does not expose submitter identity. */
app.get("/api/public/results",(req,res)=>{
  const rows=db.prepare(`
    SELECT r.id,r.status,e.type election_type,p.code pu_code,p.name pu_name,w.name ward_name
    FROM results r
    JOIN elections e ON e.id=r.election_id
    JOIN polling_units p ON p.id=r.polling_unit_id
    JOIN wards w ON w.id=p.ward_id
    WHERE r.status='Verified'
    ORDER BY e.id,w.name,p.code`).all();
  const votes=db.prepare("SELECT result_id,party,votes FROM result_votes").all();
  const by={}; for(const v of votes){(by[v.result_id]??=[]).push({party:v.party,votes:v.votes});}
  res.json(rows.map(x=>({...x,votes:by[x.id]||[]})));
});


/* Admin-only demo reset: removes all result/vote/file/audit data but keeps
   users, wards, polling units and election definitions intact. */
app.post("/api/admin/reset-demo",auth,role("Admin"),(req,res)=>{
  const confirmText=String(req.body?.confirm||"").trim();
  if(confirmText!=="RESET DEMO") return res.status(400).json({error:'Type "RESET DEMO" to confirm'});
  try{
    const files=db.prepare("SELECT stored_name FROM result_files").all();
    const tx=db.transaction(()=>{
      db.prepare("DELETE FROM result_votes").run();
      db.prepare("DELETE FROM result_files").run();
      db.prepare("DELETE FROM results").run();
      db.prepare("DELETE FROM audit_logs").run();
    });
    tx();
    for(const f of files){try{fs.unlinkSync(path.join(UPLOADS,f.stored_name));}catch(_){} }
    res.json({ok:true,message:"Demo data reset successfully",results:0,votes:0,files:0,audit_logs:0});
  }catch(e){res.status(500).json({error:"Demo reset failed"});}
});

app.get("/api/public/summary",(req,res)=>{
  const totals=db.prepare(`
    SELECT e.type election_type, COUNT(r.id) records,
      COALESCE((SELECT SUM(rv.votes) FROM result_votes rv JOIN results rr ON rr.id=rv.result_id WHERE rr.election_id=e.id AND rr.status='Verified'),0) total_votes
    FROM elections e LEFT JOIN results r ON r.election_id=e.id AND r.status='Verified'
    GROUP BY e.id ORDER BY e.id`).all();
  const party=db.prepare(`
    SELECT rv.party, COALESCE(SUM(rv.votes),0) votes
    FROM result_votes rv JOIN results r ON r.id=rv.result_id
    WHERE r.status='Verified' GROUP BY rv.party ORDER BY rv.party`).all();
  res.json({totals,party,last_updated:new Date().toISOString()});
});

app.get("/api/audit-logs",auth,role("Admin","Verifier"),(req,res)=>{
  res.json(db.prepare(`
    SELECT a.*,u.name user_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id
    ORDER BY a.id DESC LIMIT 500`).all());
});

app.get("/admin",(req,res)=>res.sendFile(path.join(ROOT,"public","admin.html")));
app.get("/results",(req,res)=>res.sendFile(path.join(ROOT,"public","public.html")));
app.get("/",(req,res)=>res.sendFile(path.join(ROOT,"public","public.html")));

app.listen(PORT,()=>console.log(`KUKSOM API running on http://localhost:${PORT}`));
