
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('Admin','Data Collector','Verifier','Viewer')),
  status TEXT NOT NULL DEFAULT 'Active',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS wards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  lga TEXT NOT NULL DEFAULT 'Kumbotso',
  state TEXT NOT NULL DEFAULT 'Kano'
);

CREATE TABLE IF NOT EXISTS polling_units (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ward_id INTEGER NOT NULL,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Active',
  FOREIGN KEY (ward_id) REFERENCES wards(id),
  UNIQUE(ward_id, code)
);

CREATE TABLE IF NOT EXISTS elections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  election_date TEXT,
  UNIQUE(type, election_date)
);

CREATE TABLE IF NOT EXISTS results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  election_id INTEGER NOT NULL,
  polling_unit_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending'
    CHECK(status IN ('Pending','Verified','Rejected')),
  submitted_by INTEGER NOT NULL,
  verified_by INTEGER,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(election_id) REFERENCES elections(id),
  FOREIGN KEY(polling_unit_id) REFERENCES polling_units(id),
  FOREIGN KEY(submitted_by) REFERENCES users(id),
  FOREIGN KEY(verified_by) REFERENCES users(id),
  UNIQUE(election_id, polling_unit_id)
);

CREATE TABLE IF NOT EXISTS result_votes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  result_id INTEGER NOT NULL,
  party TEXT NOT NULL CHECK(party IN ('APC','PDP','NDC','ADC','NNPP')),
  votes INTEGER NOT NULL CHECK(votes >= 0),
  FOREIGN KEY(result_id) REFERENCES results(id) ON DELETE CASCADE,
  UNIQUE(result_id, party)
);

CREATE TABLE IF NOT EXISTS result_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  result_id INTEGER NOT NULL,
  original_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  mime_type TEXT,
  file_size INTEGER,
  uploaded_by INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(result_id) REFERENCES results(id) ON DELETE CASCADE,
  FOREIGN KEY(uploaded_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id INTEGER,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
