KUKSOM ELECTION 2027 — V14
REAL ONLINE + PUBLIC READ-ONLY + ADMIN + DEMO MODE

What V14 adds
- Public read-only results page: /results
- Admin area: /admin
- Real Node.js/Express + SQLite backend
- Server-side JWT authentication and role checks
- Result submission + result-sheet upload
- Live Pending -> Verified/Rejected workflow
- Public API exposes Verified results only
- Admin-only DEMO RESET
- Demo reset deletes results, votes, uploaded result sheets and audit logs
- Demo reset keeps users, wards, polling units and election definitions
- Public dashboard shows verified totals only
- Same-origin deployment support

Default admin for first installation
Username: admin
Password: KUKSOM2027

IMPORTANT
Change ADMIN_PASSWORD and JWT_SECRET before any public deployment.
Do not treat the default credentials as production credentials.

Demo presentation workflow
1. Start the backend.
2. Open /admin and login.
3. Add/import the test Polling Units you want to demonstrate.
4. Submit test results with result sheets.
5. Verify them from the Live Result Verification page.
6. Open /results in another browser/device to show the public read-only view.
7. After the presentation, Admin -> Demo Reset -> type RESET DEMO.
8. Confirm the reset. Results, votes, uploaded sheets and audit logs return to zero.
9. Wards, Polling Units, election types and user accounts remain.

This is an independent KUKSOM data collection/monitoring platform. It is not affiliated with,
operated by, or endorsed by INEC. Public data must be described as KUKSOM-collected/verified,
not official INEC results.

Before 2027 production use
- Replace sample Polling Unit data with a verified current authoritative directory.
- Use HTTPS.
- Set strong JWT_SECRET and ADMIN_PASSWORD.
- Set CORS_ORIGIN to the exact frontend origin when frontend/backend are separated.
- Use PostgreSQL or another production database for larger concurrent workloads.
- Use durable object/file storage for result sheets.
- Configure backups, monitoring and rate limiting.
- Review role permissions and create separate staff accounts.
