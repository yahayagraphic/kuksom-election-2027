
KUKSOM Election 2027 — V8 Real Backend Starter

This release adds a runnable Node.js/Express backend and SQLite database.

It provides:
- JWT authentication
- bcrypt password hashing
- Admin/Data Collector/Verifier/Viewer roles
- Kumbotso ward seed data
- polling-unit API
- election API
- result submission
- verification/rejection
- result-sheet upload
- audit logs
- database constraints to prevent duplicate results for the same election + polling unit

It is a backend starter, not a deployed public website. Production deployment still requires hosting, HTTPS, secrets, backups, restricted CORS, rate limiting and verified polling-unit data.
