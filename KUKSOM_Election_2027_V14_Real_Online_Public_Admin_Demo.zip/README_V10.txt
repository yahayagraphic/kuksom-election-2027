KUKSOM ELECTION 2027 — V10 COMPLETE RESULT ENTRY SYSTEM

V10 adds a live API result-entry workflow:
- Real JWT login against the Node/SQLite backend
- Election -> Ward -> Polling Unit selectors
- APC/PDP/NDC/ADC/NNPP vote entry with validation and automatic total
- Result-sheet upload (JPG/PNG/PDF, max 10MB)
- Submission status: Pending -> Verified/Rejected
- Verified-only public results endpoint
- Live result list with file counts
- Existing audit log and role permissions retained

RUN:
1. Open a terminal inside server/
2. npm install
3. Set production secrets:
   JWT_SECRET=your-long-random-secret
   ADMIN_PASSWORD=your-strong-admin-password
4. node server.js
5. Open index.html in a browser, or serve the frontend from your web server.
6. Login using the configured admin account.

IMPORTANT:
- This is a starter/prototype architecture, not a claim of official INEC status.
- KUKSOM data must be clearly labelled independent/collected/verified data.
- Verify the current authoritative polling-unit directory before production use.
- For multi-user production at scale, PostgreSQL and proper object storage/backups are recommended.
- Use HTTPS, restricted CORS, rate limiting, strong secrets and secure hosting.
